var app = angular.module('myApp', []);

app.controller('myCtrl', ['$scope', '$http', function ($scope, $http) {

$scope.posts ={};


    $scope.submit = function () {
        $scope.data = {
            'firstname': $scope.firstname,
            'lastname': $scope.lastname,
            'address': $scope.address,
            'company': $scope.company,
            'salary': $scope.salary
        };
       
        $scope.total=0;
        $http({
            method: 'post',
            url: 'http://localhost:3000/Tasks',
            data: $scope.data

        }).then(function successCallback(response) {

            console.log("posted successfully");

        }, function errorCallback(response) {
            // called asynchronously if an error occurs

        });

        $http({
            method: 'GET',
            url: 'http://localhost:3000/Tasks'

        }).then(function successCallback(response) {
            $scope.posts = response.data;
            console.log(response.data);
        }, function errorCallback(response) {
            // called asynchronously if an error occurs

        });
          $scope.firstname="";
          $scope.lastname="";
		  $scope.address="";
		  $scope.salary="";
		  $scope.company="";
    }
	 $scope.addSalary = function () {
		 $http({
            method: 'GET',
            url: 'http://localhost:3000/Tasks'

        }).then(function successCallback(response) {
            $scope.posts = response.data;
            console.log(response.data);
        }, function errorCallback(response) {
            // called asynchronously if an error occurs

        });
		 $scope.total=0;
		  angular.forEach($scope.posts, function(item){
                   
				   if(item.company==$scope.search){
				   
					  $scope.total=$scope.total+parseInt(item.salary);
				   }  
		 
	 })
	 }


}]);