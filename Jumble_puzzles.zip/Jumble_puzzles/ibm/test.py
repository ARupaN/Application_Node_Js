import json
import re

letters=list(input("enter your string of length=3 : "))

words=[]

#length=len(letters)

for L1 in letters:
    for L2 in letters:
        for L3 in letters:
            #for L4 in letters:
             #   for L5 in letters:
                    words.append(L1+L2+L3)

with open ("diction.json",'r') as diction_json:
    data=json.load(diction_json)


for w in range(0,len(words)):
    if words[w] in data:
        print(words[w])
    else:
        print('\n')


file.close()






#     C:\Windows\System32\cmd.exe\freq_dict.json
