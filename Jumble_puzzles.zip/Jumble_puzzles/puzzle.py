from itertools import product
import json, operator

list_of_strings=[['nagld', 'ramoj', 'camble', 'wraley'],
                        ['bnedl', 'idova', 'seheyc', 'aracem'],
                            ['shast', 'doore', 'ditnic', 'catili'],
                                ['knidy', 'legia', 'cronee', 'tuvedo'],
                                    ['gyrint', 'drivet', 'snamea', 'ceedit', 'sowdah', 'elchek']]
def func(list_of_strings):
    for strings in list_of_strings:
        h=[]
        #h1=[]
        unique=[]
        print("---> given string <---")
        print(strings)

        for s in strings:
            letters=list(s)
            words=[]
##            print("the list of given string is: " + str(letters))
##            print("the sorted string is " + str(sorted(letters)) )
            x=len(letters)
##            print("the length of given string  is " +str(x))
            if x==5:
                words=[''.join(i) for i in product(letters, repeat=5)]        
            elif x==6:
                words=[''.join(i) for i in product(letters, repeat=6)]   
            elif x==7:
                words=[''.join(i) for i in product(letters, repeat=7)]
            elif x==8:
                words=[''.join(i) for i in product(letters, repeat=8)]
                
##           print("the total words formed are: " + str(len(words)))
##           print(words)

            with open ("diction.json",'r') as diction_json:
                data=json.load(diction_json)
##            print("----> the matched words are: ")
            match=[]
            for w in range(0,len(words)):
                if words[w] in data.keys():
                    match.append(words[w])
##            print(match)
##            print("----> the unique key, value are: ")
            for m in match:
                if sorted(letters)==sorted(m):
                    if m not in unique:
                        unique.append(m)
                        
##            print(unique)

            for k,v in data.items():
                for u in unique:
                    if u==k and data.get(u)>0:
                        h.append(u)
                    elif u==k and data.get(u)==0:
                        h.append(u)
           
            for k,v in data.items():
                h1=(i for i in h if i==k and data.get(i)>0)
                #print(h1)
           
        s1=[]
        for s in strings:
            s1.append(sorted(s))
        
        h2=[]
        for i in h:
            for j in s1:
                if sorted(i) == j:
                    h2.append(i)
                    s=s1.index(j)
                    del(s1[s])
        print()
        #print(h2)
      
        s_f=[]
        s_s=[]
        for f in unique:
            sf=sorted(f)
            if sf not in s_f:
                s_f.append(sf)  

        #print(s_f)
        for s in unique:
            if sorted(s) in s_f:
                s_s.append(s)
                i=s_f.index(sorted(s))
                del(s_f[i])
        
        #print(s_s)
        initial=[]
        final=[]
        q=[]
        for i in range(0,len(h2)):
            if h2[i]==s_s[i]:
                final.append(h2[i])
            else:
                initial.append(h2[i])
                initial.append(s_s[i])
                if data.get(sorted(initial)[0])>=data.get(sorted(initial)[1]):
                    final.append(sorted(initial)[0])
                else:
                    final.append(sorted(initial)[1])            
        print("---> the meaningful organised strings <---")
        print(final)
        print()

        if strings==list_of_strings[0]:
            new=[]
            for f in range(0,len(final)):
                if f==0:
                    print("first string: " + str(final[f]) )
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print("at pos 4: " +str(final[f][4]))
                    new.append(final[f][4])
                    print()
                elif f==1:
                    print("second string: " + str(final[f]) )
                    print("at pos 2: " +str(final[f][2]))
                    new.append(final[f][2])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print()
                elif f==2:
                    print("third string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print()
                elif f==3:
                    print("fourth string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 2: " +str(final[f][2]))
                    new.append(final[f][2])
                    print("at pos 4: " +str(final[f][4]))
                    new.append(final[f][4])
                    print()

            print("---> the list of all the extracted characters is: ")
            print(sorted(new))

            match4=[]
            unique4=[]

            fourLetters={}
            fourLetters1={}

            for f in [''.join(i) for i in product(new, repeat=4)]:
                if f in data.keys() and (data.get(f)==157 or data.get(f)==772):
                    if f not in unique4:
                        unique4.append(f)
                        fourLetters[f]=data[f]            
                elif f in data.keys() and (data.get(f)>0 and data.get(f)!=157 and data.get(f)!=772):
                    if f not in match4:
                        match4.append(f)
                        fourLetters1[f]=data[f]
            new1=new    
            for s in fourLetters:
                for q in s:
                    if q in new1:
                        i=new1.index(q)
                        del(new1[i])
            
            match3=[]
            unique3=[]

            threeLetters={}
            threeLetters1={}

            for f in [''.join(i) for i in product(new1, repeat=3)]:
                if f in data.keys() and data.get(f)>0:
                    if f not in unique3:
                        unique3.append(f)
                        threeLetters[f]=data[f]
                elif f in data.keys() and data.get(f)==0:
                    if f not in match3:
                        if sorted(f)==sorted(new1):
                            match3.append(f)
                            threeLetters1[f]=data[f]
           
            print()            
            print(sorted(fourLetters.items(), key=operator.itemgetter(1)))
            print()
##            print(sorted(fourLetters1.items(), key=operator.itemgetter(1)))
##            print()
##            print(sorted(threeLetters.items(), key=operator.itemgetter(1)))
##            print()
            print(sorted(threeLetters1.items(), key=operator.itemgetter(1)))
            print()
            print("When the Acupuncture worked the patient said it was a "+str(match3[0])+" "+str(unique4[1])+" "+unique4[0])
            print("********************************************************************")
        
        if strings==list_of_strings[1]:
            new=[]
            for f in range(0,len(final)):
                if f==0:
                    print("first string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 4: " +str(final[f][4]))
                    new.append(final[f][4])
                    print()
                elif f==1:
                    print("second string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print("at pos 4: " +str(final[f][4]))
                    new.append(final[f][4])
                    print()
                elif f==2:
                    print("third string: " + str(final[f]) )             
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()
                elif f==3:
                    print("fourth string: " + str(final[f]) )
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 4: " +str(final[f][4]))
                    new.append(final[f][4])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()

            print("---> the list of all the extracted characters is: ")
            print(sorted(new))
            match3=[]
            unique3=[]

            threeLetters={}
            threeLetters1={}

            for f in [''.join(i) for i in product(new, repeat=3)]:
                if f in data.keys() and data.get(f)==113 or data.get(f)==837:
                    if f not in unique3:
                        unique3.append(f)
                        threeLetters[f]=data[f]
                elif f in data.keys() and (data.get(f)>0 and (data.get(f)!=113 or data.get(f)!=837)):
                    if f not in match3:
                        match3.append(f)
                        threeLetters1[f]=data[f]
            for s in threeLetters:
                for q in s:
                    if q in new:
                        i=new.index(q)
                        del(new[i])
   
            match4=[]
            unique4=[]

            fourLetters={}
            fourLetters1={}

            for f in [''.join(i) for i in product(new, repeat=4)]:
                if f in data.keys() and data.get(f)>0:
                    if f not in unique4:
                        unique4.append(f)
                        fourLetters[f]=data[f]            
                elif f in data.keys() and data.get(f)==0:
                    if f not in match4:
                        if sorted(f)==sorted(new):
                            match4.append(f)
                            fourLetters1[f]=data[f]
            
            print()
            
            print(sorted(fourLetters.items(), key=operator.itemgetter(1)))
            print()
            print(sorted(threeLetters.items(), key=operator.itemgetter(1)))
            print()
            print("When Medusa was bitten on the neck, she had a "+ str(unique3[0])+" "+str(unique4[0])+" "+str(unique3[1]))
            print("********************************************************************")
        
        if strings==list_of_strings[2]:
            new=[]
            for f in range(0,len(final)):
                if f==0:
                    print("first string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print("at pos 4: " +str(final[f][4]))
                    new.append(final[f][4])
                    print()
                elif f==1:
                    print("second string: " + str(final[f]))
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])               
                    print()
                elif f==2:
                    print("third string: " + str(final[f]) )             
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 2: " +str(final[f][2]))
                    new.append(final[f][2])
                    print()
                elif f==3:
                    print("fourth string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 2: " +str(final[f][2]))
                    new.append(final[f][2])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()
            print("---> the list of all the extracted characters is: ")
            print(sorted(new))

##            match3=[]
##            unique3=[]

##            threeLetters={}
            threeLetters1={}
##
##            for f in [''.join(i) for i in product(new, repeat=8)]:
##                if f in data.keys() and data.get(f)==1124:
##                    if f not in unique3:
##                        unique3.append(f)
##                        threeLetters[f]=data[f]
##                elif f in data.keys() and data.get(f)>0 and data.get(f)!=1124:
##                    if f not in match3:
##                        match3.append(f)
##                        threeLetters1[f]=data[f]
            q=[]
            for f in data.keys():
                if len(f)==8 and data[f]==1124:
                    q.append(f)
                    threeLetters1[f]=data[f]
            
            for i in q:
                for j in i:
                    if j in new:
                        k=new.index(j)
                        del(new[k])                        
                    
            match4=[]
            unique4=[]

            fourLetters={}
            fourLetters1={}

            for f in [''.join(i) for i in product(new, repeat=4)]:
                if f in data.keys() and data.get(f)>0:
                    if f not in unique4:
                        if sorted(f)==sorted(new):
                            unique4.append(f)
                            fourLetters[f]=data[f]            
                elif f in data.keys() and data.get(f)==0:
                    if f not in match4:
                        if sorted(f)==sorted(new):
                            match4.append(f)
                            fourLetters1[f]=data[f]          
                                   
            print()
            print(sorted(threeLetters1.items(), key=operator.itemgetter(1)))
            print()
            print("Choosing to take the shortcut through the poision ivy was a " +str(match4[0])+" "+str(q[0]))
            print("********************************************************************")

        if strings==list_of_strings[3]:
            new=[]
            for f in range(0,len(final)):
                if f==0:
                    print("first string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print()
                elif f==1:
                    print("second string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 2: " +str(final[f][2]))
                    new.append(final[f][2])
                    print()
                elif f==2:
                    print("third string: " + str(final[f]) )             
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print()
                elif f==3:
                    print("fourth string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()
            print("---> the list of all the extracted characters is: ")
            print(sorted(new))
            
            threeLetters1={}
            q=[]
            for f in data.keys():
                if len(f)==8 and data[f]==1092:
                    if sorted(f)==sorted(new):
                        q.append(f)
                        threeLetters1[f]=data[f]            
            
##            print(sorted(threeLetters.items(), key=operator.itemgetter(1)))
            print()
            print(sorted(threeLetters1.items(), key=operator.itemgetter(1)))
            print()
            print("The math teacher hired an architect because she wanted a new "+str(q[0]))
            print("********************************************************************")

        if strings==list_of_strings[4]:
            new=[]
            for f in range(0,len(final)):
                if f==0:
                    print("first string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print()
                elif f==1:
                    print("second string: " + str(final[f]) )
                    print("at pos 2: " +str(final[f][2]))
                    new.append(final[f][2])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()
                elif f==2:
                    print("third string: " + str(final[f]) )             
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()
                elif f==3:
                    print("fourth string: " + str(final[f]) )
                    print("at pos 0: " +str(final[f][0]))
                    new.append(final[f][0])
                    print("at pos 3: " +str(final[f][3]))
                    new.append(final[f][3])
                    print()
                elif f==4:
                    print("fourth string: " + str(final[f]) )
                    print("at pos 1: " +str(final[f][1]))
                    new.append(final[f][1])
                    print("at pos 5: " +str(final[f][5]))
                    new.append(final[f][5])
                    print()
            print("---> the list of all the extracted characters is: ")
            print(sorted(new))
               
            threeLetters1={}
            q=[]
            for f in data.keys():
                if len(f)==8 and data[f]==652:
                        q.append(f)
                        threeLetters1[f]=data[f]
            for i in q:
                for j in i:
                    if j in new:
                        k=new.index(j)
                        del(new[k])
            match4=[]
            unique4=[]
##              fourLetters={}
            fourLetters1={}
##
            for f in [''.join(i) for i in product(new, repeat=6)]:
                if f in data.keys() and data.get(f)>0:
                    if f not in unique4:
                        if sorted(f)==sorted(new):
                            unique4.append(f)
                            fourLetters[f]=data[f]            
                elif f in data.keys() and data.get(f)==0:
                    if f not in match4:
                        if sorted(f)==sorted(new):
                            match4.append(f)
                            fourLetters1[f]=data[f]
            print()
            h=[("vested",0)]
            print(h)
            print()
            print(sorted(threeLetters1.items(), key=operator.itemgetter(1)))
            print()
            print("He wore an expensive three-piece suit because he had a "+str(h[0][0])+" "+str(q[0]))            
            print("********************************************************************")                
           
func(list_of_strings)
